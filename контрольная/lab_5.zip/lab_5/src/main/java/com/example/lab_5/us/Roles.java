package com.example.lab_5.us;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Roles {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id_roles;
    private String name_roles;


    public Integer getId_roles() {
        return id_roles;
    }

    public void setId_roles(Integer id_roles) {
        this.id_roles = id_roles;
    }

    public String getName_role() {
        return name_roles;
    }

    public void setName_role(String name_roles) {
        this.name_roles = name_roles;
    }

    @Override
    public String toString() {
        return "Roles{" +
                "id_roles=" + id_roles +
                ", name_role='" + name_roles + '\'' +
                '}';
    }
}
