package com.example.lab_5.us;

import jakarta.persistence.*;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_user;
    private String name;
    private String password;
    private String email;

    public Roles getId_roles() {
        return id_roles;
    }

    public void setId_roles(Roles id_roles) {
        this.id_roles = id_roles;
    }

    @ManyToOne
    @JoinColumn(name = "id_roles", referencedColumnName = "id_roles")
    private Roles id_roles;

    public Integer getId_user() {
        return id_user;
    }

    public void setId_user(Integer id_user) {
        this.id_user = id_user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "User{" +
                "id_user=" + id_user +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", email='" + email + '\'' +
                ", id_roles=" + id_roles +
                '}';
    }


}
