package com.example.lab_5.controllers;

import com.example.lab_5.exp.Br;
import com.example.lab_5.exp.Prob;
import com.example.lab_5.us.Roles;
import com.example.lab_5.us.User;
import com.example.lab_5.exp.BrRepository;
import com.example.lab_5.exp.ProbRepository;
import com.example.lab_5.us.RoleRepository;
import com.example.lab_5.us.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MainController {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BrRepository brRepository;
    @Autowired
    private ProbRepository probRepository;

    @GetMapping("/login")
    public String login() {
        return "login";
    }



    @PostMapping("/login")
    public String Login(@RequestParam String name, @RequestParam String pass) {

        try {

            User user = userRepository.findUserByNameAndPass(name, pass);
            if (user != null) {
                Roles role = user.getId_roles();
                System.out.println("Users found: " + user.getName());
                if (role != null && role.getId_roles().equals(1)) {
                    return "redirect:/admin?name=" + user.getName();
                } else {
                    return "redirect:/user?name=" + user.getName();
                }
            } else {
               return "error";
            }
        } catch (Exception e) {
            return "login";
        }
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @PostMapping("/register")
    String Register(@RequestParam String name, @RequestParam String pass, @RequestParam String mail) {
        User user = new User();
        Roles role = roleRepository.findRoleById(2);
        user.setName(name);
        user.setPassword(pass);
        user.setEmail(mail);
        user.setId_roles(role);
        userRepository.save(user);
        return "redirect:/welcome";
    }


    @GetMapping("/user")
    public String userView(@RequestParam(name = "name", required = false, defaultValue = "World") String name, Model model) {
        model.addAttribute("name", name);
        List<Br> BRI = brRepository.findAll();
        System.out.println(BRI);
        model.addAttribute("bri", BRI);
        return "user";

    }

    @GetMapping("/admin")
    public String adminView(@RequestParam(name = "name", required = false, defaultValue = "World") String name, Model model) {
        model.addAttribute("name", name);
        List<Prob> PRO = probRepository.findAll();
        System.out.println(PRO);
        model.addAttribute("pro", PRO);
        return "admin";

    }
}