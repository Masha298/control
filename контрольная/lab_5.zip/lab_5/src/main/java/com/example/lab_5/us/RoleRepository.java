package com.example.lab_5.us;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends CrudRepository<Roles, Integer> {
    @Query("SELECT r FROM Roles r WHERE r.id_roles = :id  ")
    Roles findRoleById(@Param("id") Integer id);
}
